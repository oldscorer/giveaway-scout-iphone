GIVEAWAY SCOUT — IPHONE SETUP

WHAT THIS IS
A mobile-first web app for discovering gaming/technology giveaways, saving Gleam links, and tracking entry steps. It stores its queue in Safari on your device.

IMPORTANT IOS LIMIT
iPhone apps and websites are sandboxed. This app cannot control Instagram/TikTok in the background, perform follows/comments, or reliably read Gleam's completion checks after switching apps. It opens pages and tracks your own checklist; you perform social actions and verify the entry yourself.

FASTEST WAY TO TRY IT
1. Open index.html in Safari if your iPhone offers that option. Some iOS file previews restrict web-app features; HTTPS hosting is required for Add to Home Screen and offline caching.

PUBLISH IT FROM AN IPHONE WITH GITHUB PAGES
GitHub Pages hosts static HTML/CSS/JS websites over HTTPS. A public repository is required for GitHub Free.
1. In Safari, go to https://github.com and sign in or create an account.
2. Tap +, then New repository. Name it giveaway-scout-iphone, choose Public, and create it with a README.
3. Open the new repository. Use Add file → Upload files. Upload index.html, manifest.json, and sw.js from the extracted folder. Commit the files to the main branch.
4. In the repository, open Settings → Pages.
5. Under Build and deployment, choose Deploy from a branch. Choose branch main and folder /(root), then Save.
6. Wait for GitHub Pages to publish. In Settings → Pages, tap Visit site. The address will look like https://YOUR-GITHUB-USERNAME.github.io/giveaway-scout-iphone/ .
7. Open that published address in Safari. Tap Share → Add to Home Screen → Add.
8. Launch Giveaway Scout from your Home Screen.

USING THE APP
1. Tap Browse Gleam or a gaming/tech search button.
2. In Safari, choose a giveaway and copy its URL using Share → Copy Link.
3. Return to Giveaway Scout, open Discover, paste the URL, and tap Add.
4. Open My queue and tap Open giveaway.
5. Complete tasks yourself in Gleam or the linked social app/site. Return to the app and tick off steps you completed. Verify the Gleam entry confirmation before marking the final verification step.
6. Tap Next to open the next saved giveaway. The queue stays saved in this Safari installation.

PRIVACY
No account, password, API key, or personal information is requested. Queue data is stored in localStorage in your browser. Clearing Safari website data may erase it. The app's search buttons open Google/Gleam in a new tab; search results and giveaway legitimacy are not guaranteed.

FILES
index.html — app UI and logic
manifest.json — Home Screen web-app metadata
sw.js — small offline app-shell cache
